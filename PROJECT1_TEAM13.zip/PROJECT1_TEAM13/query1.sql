select admrdept, count(*) as "CountPerDept" from department group by admrdept;
