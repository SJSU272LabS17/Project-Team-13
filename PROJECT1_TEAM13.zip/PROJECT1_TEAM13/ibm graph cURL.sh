#!/bin/bash
jq -L $HOME/jq

CT="Content-Type:application/json"

TEST="curl https://ibmgraph-alpha.ng.bluemix.net/798f6f32-9291-4594-8858-e0f05d509f4d/g/schema -X GET -u 9b09e168-a386-4e7a-a280-e30bc1afaaf2:23b32c21-f91c-41c1-93f2-93433d1f3dd0"

echo $TEST

RESPONSE=`$TEST| jq ' .result.data[].propertyKeys[].name'`
echo $RESPONSE